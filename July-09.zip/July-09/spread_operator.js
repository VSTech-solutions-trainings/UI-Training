//spread operator can be used for both arrays and objects

const arr = [1,2,3]

const newArr = [...arr]

console.log(newArr)