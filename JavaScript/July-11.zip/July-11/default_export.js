let func = function printName() {
    console.log('Mike')
}

export  const personAge = 22
export  const personAge1 = 22
export  const personAge2 = 22
export  const personAge3 = 22
export  const personAge4 = 22

export default func;