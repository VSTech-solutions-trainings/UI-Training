const userName = {
  name: "mike",
};

const userAge = {
  age: 22,
};

const userDetails = { ...userName, ...userAge };
