console.log('Started')

function addNum(num1, num2) {
    let res = num1 + num2
    console.log(res)
    return res
}

let result = addNum(3,4)
console.log(result)
console.log('Finished')

//Output
//started
//7
//7
//Finished