let person = {
    name: 'Tom',
    age: 22,
    address: '1234 st'
}

for(const key in person) {
    //console.log(person[dummy])
    console.log(key)
}

//DOT and Bracket