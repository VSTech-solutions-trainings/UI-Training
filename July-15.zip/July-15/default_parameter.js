// function addNumber(num1, num2=4) {
//     console.log(num1 + num2) //12
// }

// addNumber(3,9)

//example 2
function addNumber(num1, num2=4) {
    console.log(num1 + num2) //7
}

addNumber(3)
