(function(name, age) {
    const res = `Hello ${name} How are you ?, 
        My age is ${age}`
    console.log(res)
    return res;

})('Mike', 22)


//const result = sayHello('Mike', 22)
//console.log(result) //undefined 

//output