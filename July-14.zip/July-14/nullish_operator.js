//Nullish coalescing operator

//ternary operator - syntax ?

//nullish - syntax ?? - returns the right hand operand only if the left-hand operand is null or undefined.

let arr = []

let val = arr ?? console.log('test')

console.log(val)