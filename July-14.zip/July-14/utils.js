export let name = 'Mike'
export let otherName = 'Tom'
export default 'Example'