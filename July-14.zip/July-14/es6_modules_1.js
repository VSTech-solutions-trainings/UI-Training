import { name } from './utils.js'

console.log(name)